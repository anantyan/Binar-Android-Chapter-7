package id.anantyan.utils.validator.interfaces

interface Validate {

    fun validate(value: String?): Boolean
}
