package id.anantyan.utils.validator.constant;

public enum Mode {
    SINGLE,
    CONTINUOUS
}
